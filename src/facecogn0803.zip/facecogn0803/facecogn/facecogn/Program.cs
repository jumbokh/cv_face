﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;
using Newtonsoft.Json;
using MyLib;

namespace facecogn
{
    class Program
    {
        const string _apikey = "2689d57525d649e8b733a0c3d2b0d44e"; // get from portal.azure face resource
        const string _uri = "https://jumboface.cognitiveservices.azure.com/face/v1.0/detect";

        static async Task Main(string[] args)
        {
            string imageFilePath = Path.Combine(Environment.CurrentDirectory, "Datas", "2.jpg");

            try
            {
                await MakeAnalysisRequest(imageFilePath);
            }
            catch (Exception e)
            {
                Console.WriteLine("\n" + e.Message + "\nPress Enter to exit....\n");
            }

        }
        static async Task MakeAnalysisRequest(string imageFilePath)
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _apikey);

            string requestParameters = "returnFaceId=true&returnFaceLandmarks=false" +
                "&returnFaceAttributes=age,gender,headPose,smile,facialHair,glasses," +
                "emotion,hair,makeup,occlusion,accessories,blur,exposure,noise";

            string uri = _uri + "?" + requestParameters;

            HttpResponseMessage response;

            byte[] byteData = GetImageAsByteArray(imageFilePath);

            using (ByteArrayContent content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                response = await client.PostAsync(uri, content);

                //get the JSON response.
                string result = await response.Content.ReadAsStringAsync();

                List<Face> faceresult = JsonConvert.DeserializeObject<List<Face>>(result);

                foreach (var item in faceresult)
                {
                    Console.WriteLine(item.faceAttributes.age);
                    Console.WriteLine(item.faceAttributes.emotion);
                }
            }
        }

        static byte[] GetImageAsByteArray(string imageFilePath)
        {
            using (FileStream fileStream =
                new FileStream(imageFilePath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }

        }
    }
}
